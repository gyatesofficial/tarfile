#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Installing Airflow AWS providers + s3fs from local wheelhouse (offline)..."
pip install --no-index --find-links "$DIR/wheelhouse" -r "$DIR/requirements.txt"
echo "Done."
