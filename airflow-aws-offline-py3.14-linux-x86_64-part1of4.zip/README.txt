Offline pip bundle - Apache Airflow AWS providers + s3fs  (SPLIT INTO 4 PARTS)
===============================================================================
Target platform : CPython 3.14, Linux x86_64 (manylinux2014 / manylinux_2_17+)
Built           : 2026-06-22

Requested packages
------------------
  apache-airflow-providers-amazon     == 9.30.0
  apache-airflow-providers-common-io  == 1.7.3
  s3fs                                == 2026.6.0

Why 4 files?
-------------
The full bundle is ~80 MB. It is split into 4 zips (~20 MB each) to fit a
25 MB attachment limit. Each zip holds part of the wheelhouse.

HOW TO USE
----------
1. Put all 4 zip files in the same folder.
2. Extract ALL 4 of them into that SAME folder. Each contains a "wheelhouse/"
   directory; extracting them together merges all 157 wheels into one
   "wheelhouse/". (requirements.txt, install.sh and this README are in part 1.)
3. Install fully offline (no internet needed):

     pip install --no-index --find-links ./wheelhouse -r requirements.txt

   Or just the three top-level packages:
     pip install --no-index --find-links ./wheelhouse \
         apache-airflow-providers-amazon apache-airflow-providers-common-io s3fs

Notes
-----
- Wheels are ONLY for CPython 3.14 on Linux x86_64. They will not install on other
  Python versions, OSes, or CPU architectures. Ask for a rebuild if needed.
- Includes Apache Airflow core, since the provider packages depend on it.
- Verified: the merged wheelhouse resolves all 157 packages offline for the target.
