# Releasing the Astro Agent Helm Chart

This chart tracks two versions in `Chart.yaml`:

- **`appVersion`** — the `astro-agent-client` release pinned by the chart. Bumped automatically by the [Bump Client Version](.github/workflows/bump-client-version.yaml) workflow whenever a new client is released in [astronomer/astro-agent](https://github.com/astronomer/astro-agent). The workflow also updates image tags in `values.yaml` and `README.md`.
- **`version`** — the chart's own semver. Bumped **manually** before each chart release, so the release type (patch/minor/major) can be chosen based on what's actually changing in the chart.

## Cutting a chart release

1. Make sure `main` has all the changes (chart updates, latest `appVersion` bump) you want to ship.
2. Decide the next chart version following semver:
   - **patch** — template or values fixes, no behavioural changes for users
   - **minor** — new configurable fields, new optional templates, non-breaking additions
   - **major** — breaking changes to values schema, required user action on upgrade
3. Open a chart-version bump PR from your local clone:

   ```bash
   script/bump-chart-version <new-chart-version>
   ```

   This updates `version:` in `Chart.yaml`, pushes a branch, and opens a PR.

4. Review and merge the PR.
5. Run the [Release](.github/workflows/release.yaml) workflow against `main`, first to `internal` to validate, then to `public`.

## Notes

- Do **not** bump `version` in the same PR as an `appVersion` bump. Let the auto-generated `appVersion`/image-tag PR land on its own, then open a separate chart-version bump PR when you're ready to cut a release.
- If you ever need to ship a chart change without a new `appVersion`, bump only `version` via the script above.
