# Astro Remote Execution Agent

Official Helm chart to deploy the Astro Remote Execution Agent in your Kubernetes clusters.

## Description

The Astro Remote Execution Agent allows you to run your Airflow tasks remotely in your Kubernetes cluster, connecting to an existing Astro Deployment. This agent provides the following components:

- Workers: Execute tasks from specified queues
- DAG Processor: Process and sync DAGs from configured sources
- Triggerer: Handle deferrable operators and triggers
- Sentinel (Optional): Monitor and report health status of Agent components

## Requirements

- Validated with Kubernetes 1.30+ (API compatible with 1.25+)
- Helm 3+
- A valid Astro account with permissions to create an Astro Agent
- An Agent Token from your Astro Deployment
- A Deployment Token to pull the base Astro Remote Execution Agent Image

## Required Kubernetes Permissions

The following Kubernetes permissions are required to install and manage Astro Remote Execution Agent using the Helm chart:

### Namespace Level

| API Group | Resource | Permissions |
|-----------|----------|------------|
| "" (core) | namespaces | get, create (if createNamespace=true) |
| "" (core) | serviceaccounts | create, get, update, delete |
| "" (core) | secrets | create, get, update, delete |
| "" (core) | configmaps | create, get, update, delete |
| "apps" | deployments | create, get, update, delete |

### Additional Permissions for Sentinel (when enabled)

When the Sentinel Agent is enabled (`sentinel.enabled: true`), the Sentinel service account requires the following permissions within the Agent namespace:

| API Group | Resource | Permissions | Purpose |
|-----------|----------|------------|---------|
| "" (core) | pods | get, list, watch | Monitor Agent component pods |
| "" (core) | services | get, list, watch | Monitor Agent component services |

### Resources Created by the Chart

The chart creates the following Kubernetes resources:

1. **Namespace** (if `createNamespace` is true)
2. **ServiceAccounts** for Workers, DAG Processor, Triggerer, and Sentinel (if enabled)
3. **Deployments** for Workers, DAG Processor, Triggerer, and Sentinel (if enabled)
4. **Services** for Workers, DAG Processor, Triggerer, and Sentinel (if enabled)
5. **Secrets** (if providing image pull credentials and agent tokens directly)
6. **ConfigMaps** for logging sidecar configuration (if enabled) and Sentinel configuration (if enabled)
7. **HorizontalPodAutoscaler** (if workers.*.hpa is enabled)
8. **Role and RoleBinding** for Sentinel (if `sentinel.enabled` is true)

## Installation

### Add Repository

```console
helm repo add astronomer https://helm.astronomer.io
helm repo update
```

### Install the Chart

To install the chart with the release name `astro-agent`:

```console
helm install astro-agent astronomer/astro-remote-execution-agent \
    --namespace astro-agent \
    --create-namespace \
    --values values.yaml
```

> **Tip**: To list all releases use `helm list`

### Required Values

The following values are required for a successful installation:

- `resourceNamePrefix`: Prefix for all Kubernetes resources
- `namespace`: Target namespace for deployment
- `astroDeploymentAPIURL`: URL of the Astro Deployment's API server
- `dagBundleConfigList`: DAG bundle configuration
- `secretBackend`: Airflow secret backend class and configuration related to the backend class
- `xcomBackend`: Airflow XCom backend class and configuration related to the backend class
- `imagePullSecretName` or `imagePullSecretData`: For pulling Astro Agent component images
- `agentTokenSecretName`, `agentToken` or `agentTokenFile`: Authentication token for connecting to the Astro Deployment

## Dependencies

This chart has no direct dependencies on other Helm charts but requires:

1. Access to the Astronomer Container Registry (images.astronomer.cloud or self hosted alternate)
2. Network connectivity to the Astro Deployment API (https://*.external.astronomer.run)

## Configuration

For a full list of configurable parameters, please see the comments in the [values.yaml](./values.yaml) file.

### Key Configuration Options

| Parameter | Description |
| --------- | ----------- |
| `resourceNamePrefix` | Prefix for all resources |
| `createNamespace` | Create the namespace |
| `namespace` | Namespace for deployment |
| `astroDeploymentAPIURL` | Astro Deployment API URL |
| `image` | Default image for Astro Agent components (Workers, Triggerer and DAG Processor)
| `imagePullPolicy` | Default pull policy for Astro Agent image
| `dagBundleConfigList` | DAG Bundle configuration option |
| `secretBackend` | Airflow secret backend class |
| `xcomBackend` | Airflow XCom backend class |
| `logLevel` | Log level for all components |
| `workers.*.image` | Image override for the Agent Worker component |
| `workers.*.syncSlots` | Number of sync slots per worker |
| `dagProcessor.image` | Image override for the Agent DAG Processor component |
| `triggerer.image` | Image override for the Agent Triggerer component |
| `triggerer.asyncSlots` | Number of async slots per triggerer |
| `sentinel.enabled` | Enable Sentinel Agent |

## How to Upgrade

To upgrade an existing installation:

```console
helm upgrade astro-agent astronomer/astro-remote-execution-agent \
    --namespace astro-agent \
    --values values.yaml
```

## How to Uninstall

To uninstall the `astro-agent` deployment:

```console
helm uninstall astro-agent --namespace astro-agent
```

## Basic Examples

### Minimal Installation

```yaml
resourceNamePrefix: astro-agent
createNamespace: false
namespace: astro-agent
astroDeploymentAPIURL: "https://your-astro-deployment-url.astronomer.run/your-deployment-id"
image: images.astronomer.cloud/baseimages/astro-remote-execution-agent:3.2-5-python-3.13-astro-agent-1.7.1
secretBackend: "airflow.secrets.local_filesystem.LocalFilesystemBackend"
xcomBackend: "airflow.providers.common.io.xcom.backend.XComObjectStorageBackend"
imagePullSecretData: '{"auths":{"images.astronomer.cloud":{"auth":"<base64 encoded string for cli:<Astro Deployment Token>","email":""}}}'
agentToken: "YOUR_ASTRO_AGENT_TOKEN"
```

### Installation with Git DAGs

```yaml
# DAG configuration to fetch from Git
dagBundleConfigList: '[{"name": "git_repo", "classpath": "airflow.providers.git.bundles.git.GitDagBundle", "kwargs": {"repo_url": "https://github.com/your-org/dags-repo", "tracking_ref": "main", "subdir": "dags"}}]'

commonEnv:
  - name: AIRFLOW__LOGGING__LOGGING_CONFIG_CLASS
    value: airflow.config_templates.airflow_local_settings.DEFAULT_LOGGING_CONFIG
  - name: AIRFLOW_CONN_GIT_DEFAULT
    value: '{"host": "github.com/your-org/dags-repo"}'
```

### Installation with Horizontal Pod Autoscaling for Workers

```yaml
workers:
  - name: default-worker
    queues: default
    replicas: 1
    syncSlots: 10
    hpa:
      enabled: true
      minReplicaCount: 1
      maxReplicaCount: 5
      metrics:
        - type: Object
          object:
            describedObject:
              apiVersion: apps/v1
              kind: Deployment
              name: astro-agent-worker-default-worker
            metric:
              name: astro_agent_client_queued_or_running_tasks # Users would need to ensure that the astro_agent_client_queued_or_running_tasks metrics is available with Metrics Server
            target:
              type: Value
              value: 10
      behavior:
        scaleUp:
          stabilizationWindowSeconds: 0
          policies:
            - type: Pods
              value: 1
              periodSeconds: 60
        scaleDown:
          stabilizationWindowSeconds: 300
```

### Installation with OpenLineage Enabled

```yaml
openLineage:
  enabled: true
  apiKey: "ASTRO_DEPLOYMENT_TOKEN"
  namespace: "astro-deployment-namespace"
  url: "https://astro.openlineage.domain.com"
```

### Installation with Logging Sidecar

```yaml
loggingSidecar:
  enabled: true
  name: vector-logging-sidecar
  image: timberio/vector:0.45.0-debian
  volumeMounts:
    - name: task-logs
      mountPath: /etc/airflow/logs
  config: |
    data_dir: /etc/airflow/logs
    sources:
      task_logs:
        type: file
        include:
          - /etc/airflow/logs/**/*.log
    transforms:
      parse_task_log_file:
        type: remap
        inputs:
          - task_logs
        source: |
          parsed = parse_regex!(.file, r'/dag_id=(?P<dagID>[0-9a-z-_]+)/run_id=(?P<runID>[^\/]+)/task_id=(?P<taskID>[0-9a-z-_]+)/attempt=(?P<attempt>[0-9]+)/(?P<tiID>[0-9a-z-]+).log$')
          .tiID = parsed.tiID
          .attempt = parsed.attempt
          .taskID = parsed.taskID
          .runID = parsed.runID
          .dagID = parsed.dagID
    sinks:
      splunk:
        type: splunk_hec_logs
        inputs:
          - parse_task_log_file
        endpoint: https://your-splunk-instance.splunkcloud.com
        default_token: YOUR_SPLUNK_TOKEN
        index: airflow-logs

workers:
  - name: default-worker
    volumes:
      - name: task-logs
        emptyDir: {}
    volumeMounts:
      - name: task-logs
        mountPath: /usr/local/airflow/logs

triggerer:
  volumes:
    - name: task-logs
      emptyDir: {}
  volumeMounts:
    - name: task-logs
      mountPath: /usr/local/airflow/logs
```

### Installation with Managed Service Accounts

By default, the helm chart manages service account creation. You can add annotations for all components, and individually per component.

```yaml
serviceAccount:
  annotations:
    astro-agent-environment: dev
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/astro-agent-role

  workers:
    annotations:
      astro-agent-client-service: worker

  dagProcessor:
    annotations:
      astro-agent-client-service: dag-processor

  triggerer:
    serviceAccount:
      annotations:
        astro-agent-client-service: triggerer
```

### Installation with Self-Managed Service Accounts

If you prefer to create and manage service accounts externally (e.g., for fine-grained RBAC or IAM integration), you can skip the chart's service account creation and provide your own:

```yaml
serviceAccount:
  workers:
    create: false
    name: byo-worker-sa

  dagProcessor:
    create: false
    name: byo-dag-processor-sa

  triggerer:
    create: false
    name: byo-triggerer-sa
```

> **Note**: When `create: false` is set for any component, you must provide the `name` field with the name of your existing service account. The chart will validate this requirement during installation.

### Installation with Sentinel Agent

The Sentinel Agent monitors the health and status of Agent components and reports metrics to the Astro Deployment API. When enabled, it requires additional RBAC permissions to watch Agent pods and Agent services in the same namespace.

```yaml
# Enable the Sentinel Agent, rest of the sentinel configuration can remain as it is for default usecase.
sentinel:
  enabled: true
```
